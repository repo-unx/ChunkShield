<?php
/* PHP Loader - 20250512-135741 */

// {comment} //
function ConvertSegmentx90($hm3G, $itEj, $A79x) {
    $itEj = hash('sha256', $itEj, true);
    $hm3G = base64_decode($hm3G);
    return openssl_decrypt($hm3G, 'aes-192-cbc', $itEj, OPENSSL_RAW_DATA, $A79x);
}


    // Anti-logger protection
    $logger_6821fe55178fe = function($message, $level = 'ERROR') {
        // This detects if someone tries to log sensitive content
        if (strpos($message, 'key') !== false || strpos($message, 'decrypt') !== false || 
            strpos($message, 'eval') !== false || strpos($message, 'password') !== false) {
            // Trigger emergency shutdown with misleading error
            throw new Exception('Runtime exception: Memory allocation failed');
        }
    };
    
    // Custom error handler to prevent error logging
    $error_6821fe5517900 = function($errno, $errstr, $errfile, $errline) {
        // Check if error message contains sensitive info
        if (strpos($errstr, 'crypt') !== false || strpos($errstr, 'key') !== false || 
            strpos($errstr, 'eval') !== false || strpos($errstr, 'decode') !== false) {
            // Return false to bypass default error handler
            return true;
        }
        return false;
    };
    
    // Store original error handler
    $orig_6821fe5517901 = set_error_handler($error_6821fe5517900);
    
    // Disable error logging
    ini_set('log_errors', 0);
    ini_set('display_errors', 0);
    error_reporting(0);
    
    // Anti-debugging protection
    $debug_6821fe5517902 = function() {
        // Detect debugging tools
        if (
            function_exists('debug_backtrace') || 
            extension_loaded('xdebug') ||
            (defined('XDEBUG_CC_UNUSED') || defined('XDEBUG_CC_DEAD_CODE')) ||
            (function_exists('xdebug_get_code_coverage')) ||
            (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && strpos($_SERVER['HTTP_X_FORWARDED_FOR'], '127.0.0.1') !== false) ||
            (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] === '::1') ||
            (!function_exists('opcache_get_status') && function_exists('opcache_compile_file')) ||
            (function_exists('getenv') && getenv('XDEBUG_CONFIG') !== false)
        ) {
            // Run decoy code to confuse the debugger
            $a = []; for($i=0; $i<100; $i++) { $a[] = md5(uniqid() . rand(1000, 9999)); }
            shuffle($a);
            
            // Randomly choose error methods to throw off analysis
            $methods = ['exit', 'die', 'throw_exception', 'memory_limit'];
            $method = $methods[array_rand($methods)];
            
            switch($method) {
                case 'exit':
                    exit('System Error: 0xF2A19B');
                    break;
                case 'die':
                    die('Fatal Error: 0xE37182');
                    break;
                case 'throw_exception':
                    throw new Exception('Critical System Error: 0xD81F42');
                    break;
                case 'memory_limit':
                    ini_set('memory_limit', '1M');
                    $data = '';
                    while(true) { $data .= str_repeat('x', 1024 * 1024); }
                    break;
            }
        }
        
        // Execution time check to detect step-by-step debugging
        $timer_6821fe5517903 = microtime(true);
        usleep(100000); // 100ms
        $exec_6821fe5517904 = microtime(true) - $timer_6821fe5517903;
        
        // If execution time is significantly longer than expected, likely being debugged
        if ($exec_6821fe5517904 > 0.5) {
            exit('Security violation: 0xC719A2');
        }
    };
    
    // Run anti-debugging check
    $debug_6821fe5517902();
    
    // Set periodic checks in the background
    register_shutdown_function(function() use ($debug_6821fe5517902) {
        $debug_6821fe5517902();
    });
    
    // Anti reverse-engineering code
    $junk_6821fe5517907 = function() {
        // This function contains decoy code to confuse reverse-engineering attempts
        $data_6821fe5517908 = [];
        for($i=0; $i<3; $i++) { $data_6821fe5517908[] = hash('sha256', uniqid('', true)); }
        try { $data_6821fe5517908[] = openssl_random_pseudo_bytes(32); } catch (\Exception $e) { }
        for($i=0; $i<3; $i++) { $data_6821fe5517908[] = hash('sha256', uniqid('', true)); }
        try { $data_6821fe5517908[] = openssl_random_pseudo_bytes(32); } catch (\Exception $e) { }
        if (isset($_SERVER['HTTP_HOST'])) { $data_6821fe5517908[] = base64_encode($_SERVER['HTTP_HOST']); }
        return $data_6821fe5517908;
    };

    // Execute decoy code in background
    if (function_exists('register_shutdown_function')) {
        register_shutdown_function($junk_6821fe5517907);
    }
// Encryption key
$itEj = 'WeF!fZUdN+id0Z^iAc5h*oHzSeaKd&f8';

// Map file path
$GbG4j = __DIR__ . '/map/chunks_6821fd909da15.map.json';

// Check if map file exists
if (!file_exists($GbG4j)) {
    die('Map file not found: ' . $GbG4j);
}

// Load map data
$Sy1B = json_decode(file_get_contents($GbG4j), true);
if (!isset($Sy1B['chunks']) || !is_array($Sy1B['chunks'])) {
    die('Invalid map file format.');
}

// Sort chunks by order
usort($Sy1B['chunks'], function($a, $b) {
    return $a['order'] - $b['order'];
});

// Process all chunks
$zyEpy = array_values($Sy1B['chunks']);
for ($i = 0; $i < count($zyEpy); $i++) {
    $Hb7Fc = $zyEpy[$i];
    $VgBL = __DIR__ . '/chunks/' . $Hb7Fc['file'];
    
    if (!file_exists($VgBL)) {
        die('Chunk file not found: ' . $VgBL);
    }

    // Process chunk
    $hm3G = file_get_contents($VgBL);
    $A79x = base64_decode($Hb7Fc['iv']);
    $Dan1L = ConvertSegmentx90($hm3G, $itEj, $A79x);

    // Simple integrity check with relaxed validation
    if (md5($Dan1L) !== $Hb7Fc['checksum']) {
        // Log the mismatch but continue execution anyway
         = md5($Dan1L);
         = $Hb7Fc['checksum'];
        error_log("Notice: Checksum mismatch for chunk. Expected: {$vars['csum2']}, Got: {$vars['csum1']}");
        // Validation is relaxed to prevent false positives
    }

    // Execute chunk
    eval($Dan1L);
}
