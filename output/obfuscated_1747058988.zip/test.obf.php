<?php
 define('APP_NAME', base64_decode("U2VjdXJlU3RhdHMgUHJv")); define('VERSION', base64_decode("Mi4zLjE=")); class _SJrwh9kSEZnh { public $_C3Y1Q5Wd; public $_LXJHTHE3; public $_U4CmPPV6; public function __construct($_C3Y1Q5Wd, $_LXJHTHE3, $_U4CmPPV6) { $this->name = $_C3Y1Q5Wd; $this->role = $_LXJHTHE3; $this->email = $_U4CmPPV6; } public function _e6BGLbqRBM() { return "
            <div class='card'>
                <h3>" . htmlspecialchars($this->name) . "</h3>
                <p>Role: {$this->role}</p>
                <p>Email: {$this->email}</p>
            </div>
        "; } } function _Or847fJ8DA(array $_QgjHLYGR) { $_sFVw5OyX = 0; foreach ($_QgjHLYGR as $_7leEjHMm => $_TLx0Z45M) { $_sFVw5OyX += ($_TLx0Z45M * 1.5); } $_1WkwvROs = ($_sFVw5OyX > 100) ? 20 : 5; return $_sFVw5OyX + $_1WkwvROs; } $_PAfzF5Zp = [ new _SJrwh9kSEZnh("Alice", "Admin", base64_decode("YWxpY2VAZXhhbXBsZS5jb20=")), new _SJrwh9kSEZnh("Bob", "Editor", base64_decode("Ym9iQGV4YW1wbGUuY29t")), new _SJrwh9kSEZnh("Charlie", "Viewer", base64_decode("Y2hhcmxpZUBleGFtcGxlLmNvbQ==")), ]; $_QgjHLYGR = [ 'visits' => 120, 'clicks' => 75, 'shares' => 30, ]; ?>
<!DOCTYPE html>
<html>

<head>
    <title><?= APP_NAME ?> v<?= VERSION ?></title>
    <style>
    body {
        font-family: sans-serif;
        padding: 30px;
        background: #f2f2f2;
    }

    h1 {
        color: #444;
    }

    .user-list {
        display: flex;
        gap: 20px;
    }

    .card {
        background: white;
        padding: 15px;
        border-radius: 10px;
        box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
        width: 200px;
    }

    .section {
        margin-bottom: 30px;
    }
    </style>
</head>

<body>

    <h1><?= APP_NAME ?> <small style="font-weight: normal;">v<?= VERSION ?></small></h1>

    <div class="section">
        <h2>👥 User List</h2>
        <div class="user-list">
            <?php foreach ($_PAfzF5Zp as $_thGrbSvT): ?>
            <?= $_thGrbSvT->_e6BGLbqRBM(); ?>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="section">
        <h2>📊 Performance Calculation</h2>
        <p>Input Metrics:</p>
        <ul>
            <?php foreach ($_QgjHLYGR as $_yW3dcyIB => $_fF5HeUsv): ?>
            <li><strong><?= ucfirst($_yW3dcyIB) ?>:</strong> <?= $_fF5HeUsv ?></li>
            <?php endforeach; ?>
        </ul>
        <?php
 $_VRNdFAG1 = _Or847fJ8DA($_QgjHLYGR); ?>
        <p><strong>Total Score:</strong> <?= $_VRNdFAG1 ?></p>
    </div>

</body>

</html>